/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author invitado
 */
public class Nodo {
  private int valor;
    private Nodo izq;
    private Nodo der;

    public Nodo(/*Nodo siguiente*/) {
        this.izq = null;
        this.der = null;
    }

    public Nodo(int valor) {
        this.valor = valor;
        this.der = null;
        this.izq=null;
    }
    
    
    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }

    public Nodo getIzq() {
        return izq;
    }

    public void setIzq(Nodo siguiente) {
        this.izq = siguiente;
    } 
    public Nodo getDer() {
        return der;
    }
    public void setDer(Nodo anterior) {
        this.der = anterior;
    } 

    
}
