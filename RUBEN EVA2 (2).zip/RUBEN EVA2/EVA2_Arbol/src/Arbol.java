/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author invitado
 */
public class Arbol {
    private Nodo root;
        public Arbol(){
            root=null;
        }
        public void agregarNodo(Nodo nuevo){
            agregarNodoRec(root, nuevo);
        }
        private void agregarNodoRec(Nodo actual , Nodo nuevo){
            if (root == null){//arbol vacio
                root=nuevo;
            } else {
                if(nuevo.getValor()> actual.getValor()){//Mayor ---> derecha
                    if(actual.getDer() == null){
                        actual.setDer(nuevo);
                    } else {//ups, ya hay um nodo
                        agregarNodoRec(actual.getDer(), nuevo);
                    }
                } else if(nuevo.getValor() < actual.getValor()){ //Menor--> izquierda
                   if(actual.getIzq() == null){
                        actual.setIzq(nuevo);
                    } else {//ups, ya hay um nodo
                        agregarNodoRec(actual.getIzq(), nuevo);
                    } 
                } else {//el valor ya existe
                    System.out.println("ups! ya existe el valor");
                    
                }
            }
        }
        public void imprimiePostOrder(){
            postOrden(root);
        }
        private void postOrden(Nodo actual){
            if (actual !=null){
            //leer izq
            postOrden(actual.getIzq());
            //leer der
            postOrden(actual.getDer());
            //imprimir
            System.out.print(actual.getValor() + " - ");
            }
        }
        public void imprimieInOrder(){
            InOrder(root);
        }
        private void InOrder(Nodo actual){
            if (actual !=null){
            //leer izq
            InOrder(actual.getIzq());
            //imprimir
            System.out.print(actual.getValor() + " - ");
            //leer der
            InOrder(actual.getDer());
            
            }
        }
        public void imprimiePreOrder(){
            PreOrder(root);
        }
        private void PreOrder(Nodo actual){
            if (actual !=null){
            //imprimir
            System.out.print(actual.getValor() + " - ");
            //leer izq
            PreOrder(actual.getIzq());
            //leer der
            PreOrder(actual.getDer());
            
            }
        }
}

