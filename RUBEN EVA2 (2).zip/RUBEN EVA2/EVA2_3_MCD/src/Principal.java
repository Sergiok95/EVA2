/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author invitado
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println(mcd(33,23));
        
    }
    public static int mcd (int dividendo,int divisor){
        //cuando detenemos recursion?
        System.out.println(dividendo + "/" + divisor);
        if(divisor ==0){
          return dividendo;
      }else {
          int iResi = dividendo % divisor;
          return mcd (divisor, iResi);
                  }
    }
}
