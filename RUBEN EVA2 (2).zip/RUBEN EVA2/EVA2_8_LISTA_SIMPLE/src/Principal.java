
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author invitado
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Lista miLista = new Lista();
        miLista.add(new Nodo(4));//1
        miLista.add(new Nodo(24));//2
        miLista.add(new Nodo(48));//3
        miLista.add(new Nodo(5));//4
        miLista.add(new Nodo(28));//5
        miLista.addBegin(new Nodo(999999));//0
        miLista.print();
        //System.out.println();
        miLista.insertAt(2,new Nodo(84) );
        miLista.print();
        //System.out.println();
        boolean vacia = miLista.isEmpty();
            if(vacia)
                System.out.println("Lista vacia");
            else
                System.out.println("Lista con nodos");
            
       
        System.out.println("Cantidad =" + miLista.size());
        try {
            miLista.deleteAt(0);
            miLista.print();
            miLista.add(new Nodo(200));
            miLista.print();
            miLista.deleteAt(6);
            miLista.print();
            miLista.add(new Nodo(250));
            miLista.print();
        } catch (Exception ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("El valor es " + miLista.getAt(3));
    }
    
}
