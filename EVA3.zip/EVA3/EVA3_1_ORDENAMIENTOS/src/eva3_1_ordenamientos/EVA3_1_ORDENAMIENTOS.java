/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eva3_1_ordenamientos;

/**
 *
 * @author invitado
 */
public class EVA3_1_ORDENAMIENTOS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int[] datos = new int[20];
         long ini,fin;
        /*llenar(datos);
        imprimir(datos);
        ini  = System.nanoTime();
        selectionSort(datos);
        fin = System.nanoTime();
        imprimir(datos);
        System.out.println("tiempo = " + (fin-ini));
        
        llenar(datos);
        imprimir(datos);
        ini  = System.nanoTime();
        insertionSort(datos);
        fin = System.nanoTime();
        imprimir(datos);
        System.out.println("tiempo = " + (fin-ini));
        
        llenar(datos);
        imprimir(datos);
        ini  = System.nanoTime();
        bubbleSort(datos);
        fin = System.nanoTime();
        imprimir(datos);
        System.out.println("tiempo = " + (fin-ini));*/
        
        llenar(datos);
        imprimir(datos);
        ini  = System.nanoTime();
        quickSort(datos);
        fin = System.nanoTime();
        imprimir(datos);
        System.out.println("tiempo = " + (fin-ini));
        
        
    }
    public static void llenar(int[] arreglo){
        for (int i = 0; i < arreglo.length; i++) {
            arreglo[i]= (int)(Math.random()*100);
        }
    }
    public static void imprimir(int[] arreglo){
        for (int i = 0; i < arreglo.length; i++) {
            System.out.print(" [" + arreglo[i] + "] ");
        }
        System.out.println("");
    }
    
    public static void selectionSort(int[] arreglo){
        for (int i = 0; i < arreglo.length; i++) {
            int min = i;
            
            for (int j = i+1; j < arreglo.length; j++) {
                if(arreglo[j] < arreglo[min]){
                    min = j;
                }
                //SWAP
                int temp = arreglo[i];
                    arreglo[i] = min;
                    arreglo[min] = temp;
                
            }
            
        }
    }
    //O(n°2)
    //hace mas comparaciones , menos intercabiar
    public static void insertionSort ( int[] arreglo){
        for(int i = 1; i < arreglo.length; i++){
            int iTemp = arreglo[i];
            int insP;
            for ( insP = i; insP > 0 ; insP--){
                int iPrev = insP -1;
                if ( arreglo[iPrev] > iTemp){
                    //SWAP
                    arreglo[insP] = arreglo [iPrev];
                } else {
                    break;
                }
                
            }
            arreglo[insP] = iTemp;
        }
    }
    
    public static void bubbleSort(int[] arreglo){
        for (int i = 0; i < arreglo.length  ; i++) {
            for (int j = 0; j < arreglo.length -1; j++) {
                if (arreglo[j] > arreglo[j+1]){
                    int iTemp= arreglo[j];
                    arreglo[j]=arreglo[j+1];
                    arreglo[j+1] = iTemp;
                }
            }
        }
    }
    public static void quickSort(int[] arreglo){
        quickSortRec(arreglo, 0 ,arreglo.length-1); 
        
    }
    private static void quickSortRec(int[] arreglo , int ini , int fin){
        //Detenermos 
        if((ini< fin)&&(ini>=0)&&(fin < arreglo.length)){
            int iPiv = ini;
            int too_big = ini +1;
            int too_small = fin;
            int iTemp;
            while(too_big <= too_small){
                while( (too_big < fin)&&(arreglo[too_big]< arreglo[iPiv]) ){
                    too_big++;
                }
                
                    while( (too_small < (ini +1))&&(arreglo[too_small] > arreglo[iPiv]) ){
                        too_small--; 
                    }
                    
                    if (too_big < too_small)/*no hay cruce*/{
                    iTemp = arreglo[too_big];
                    arreglo[too_big] = arreglo[too_small];
                    arreglo[too_small]= iTemp;
                    }
            }
        //swap en el pivote
        iTemp = arreglo[iPiv];
        arreglo[iPiv] = arreglo[too_small];
        arreglo[too_small]= iTemp;
        
        quickSortRec(arreglo, ini,too_small -1);//iZQ
        quickSortRec(arreglo,too_small +1 , fin);//DER
        }
        
        
    }
        
}
    

