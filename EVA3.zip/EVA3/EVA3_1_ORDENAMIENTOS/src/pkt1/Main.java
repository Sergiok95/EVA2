/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkt1;

/**
 *
 * @author Pavel Ivan Montes Bissio Practica 1
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int miArray [] = new int[20];
        
        //selectionSort
        llenar(miArray);
        imprimir(miArray);
        long ini , fin;
        ini = System.nanoTime();
        selectionSort(miArray);
        fin = System.nanoTime();
        imprimir(miArray);
        System.out.println("Tiempo = " + (fin - ini));
        
        //InsertionSort
        llenar(miArray);
        imprimir(miArray);
        ini = System.nanoTime();
        insertionSort(miArray);
        fin = System.nanoTime();
        imprimir(miArray);
        System.out.println("Tiempo = " + (fin - ini));
        
        //BubbleSort
        ini = System.nanoTime();
        bubleSort(miArray);
        fin = System.nanoTime();
        imprimir(miArray);
        System.out.println("Tiempo = " + (fin - ini));
        
        //QuickSort
        ini = System.nanoTime();
        quickSort(miArray);
        fin = System.nanoTime();
        imprimir(miArray);
        System.out.println("Tiempo = " + (fin - ini));
        
        
    }
    public static void llenar (int [] arreglo){
        for (int i = 0; i < arreglo.length; i++) {
            arreglo [i] =  (int)  (Math.random()* 99 );
             
        }
    }
    public static void imprimir(int [] arreglo){
        for (int i = 0; i < arreglo.length; i++) {
            System.out.print("[ "+arreglo[i ] + " ]");
        }
        System.out.println("");
    }
    
    // O (N 2)
    public static void selectionSort(int [] arreglo){
        for (int i= 0; i< arreglo.length; i++) {
            int min = i;
            for (int j = i + 1; j < arreglo.length; j++) {
               if (arreglo [j] < arreglo[min])
                   min = j;
            }
            //Swap -  intercambio de variables 
            int temp = arreglo[i];
            arreglo [i] = arreglo [min];
            arreglo [min] = temp;
            
        }
        
    }
    // O (n2)
    //Hace nas intercambios, menos comparaciones
    public static void insertionSort(int [] arreglo){
        int insP;
        for (int i = 1; i < arreglo.length; i++) {
            int temp = arreglo[i];
            for (insP = i; insP > 0; insP--) {
                int previo = insP - 1;
                if (arreglo[previo] > temp){
                    //Swap
                   arreglo[insP] = arreglo[previo];
                   
                }else{
                    break;
                }
            }
            
            arreglo[insP] = temp;          
        }
    }
    //Este es mas lento
    //o (n2)
    public static void bubleSort (int[] arreglo){
        for (int i = 0; i < arreglo.length ; i++) {
            for (int j = 0; j > arreglo.length - 1; j++) {
                if (arreglo [j] < arreglo[j+1]){
                    //Swap 
                    int temp = arreglo[j];
                    arreglo[j] = arreglo[j+1];
                    arreglo[j + 1] = temp;
                }
            }
        }
    }
  public static void quickSort(int arreglo[]){
      quickSortRec(arreglo, 0, arreglo.length - 1);
  }
  
  private static void quickSortRec(int arreglo [] , int ini ,  int fin){
      //Detener
      if ((ini >=0 ) && (fin <= arreglo.length)&& (ini < fin)) {
          
      
  
      int pivote = arreglo [ini];
      int too_big = ini + 1;
      int too_small = fin;
      int temp;

      while(too_big < too_small){
        while ((too_big < fin) &&( arreglo[too_big] < arreglo[pivote]))      
          too_big++;
      
        while ((too_small > (ini + 1)) &&( arreglo[too_small] > arreglo[pivote]))      
          too_small--;
        
        if (too_big < too_small) { //No se han cruzado
          temp = arreglo [too_small];
          arreglo[too_small] = arreglo[too_big];
          arreglo[too_big] = temp;
          
        }
      }
      //Swap el pivote
      temp = arreglo[pivote];
      arreglo[pivote] = arreglo[too_small];
      arreglo[too_small] = temp;
      
      quickSortRec(arreglo, ini, pivote - 1); //Izq
      quickSortRec(arreglo, pivote + 1, fin); //Der
      
  }
    }
  }
    

