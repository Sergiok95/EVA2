/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.eva3_2_comparater;

import java.util.Comparator;
import java.util.LinkedList;

/**
 *
 * @author Sergio Ivan
 */
public class Principal {
   public static void main(String[] args) {
        // TODO code application logic here
        LinkedList<Integer> lista = new LinkedList<>();
        //llenarList(lista);
        llenarList(lista);
        printList(lista);
        Comparator c = (Comparator) (Object v1, Object v2) -> {
            int resultado;
            Integer valor1 =(Integer) v1;
            Integer valor2 = (Integer)v1;
            //Cero --> Igual
            //Negativo -->Menor
            //Positivo --> Mayor
            resultado = valor1 - valor2;
            return resultado;
        };
        
        
        lista.sort(c);
        System.out.println("");
        printList(lista);
        
        LinkedList <String> listaS =  new LinkedList<>();
        listaS.add("Hola");
        listaS.add(" ");
        listaS.add("Mundo");
        listaS.add(" "); // Al momento de comparar 
        listaS.add("Cruel");
        listaS.add("!!");
        
        Comparator cS = (Comparator) (Object t1, Object t2) -> {
            String s1 = (String) t1;
            String s2 = (String) t2;
            
            char c1 = s1.charAt(0);
            char c2 = s2.charAt(0);
            
            return c1 - c2;
        };
        
        System.out.println(listaS);
        listaS.sort(cS);
        System.out.println(listaS);
        
    }
    
    public static void printList(LinkedList<Integer> lista){
        for (int i = 0; i < lista.size(); i++) {
            System.out.print("[" + lista.get(i) + "]");        }
    }
     public static void llenarList(LinkedList<Integer> lista){
        for (int i = 0; i < 20; i++) {
            int p =  (int) (Math.random() * 100);
            lista.add(p);
        }
    }
    public static int busquedaBin(int[] arreglo, int val){
        return busquedaBinRec(arreglo, val, 0, arreglo.length -1);
    }
    public static int busquedaBinRec(int[] arreglo,int val,int ini,int fin){
        if (ini<=fin){
            int mid = ini +((fin-ini)/2 );
        
            if ( val ==arreglo[mid]){//Igual
            return mid;
            } else if(val> arreglo[mid]){//Mayor
            return busquedaBinRec(arreglo, val, mid +1, fin);
            }else if(val< arreglo[mid]){//Menor
            return busquedaBinRec(arreglo, val, ini, mid - 1);
            
            }
        }else
            return -1;
    
    }
}
